$(document).ready(function(){
    var timer;
   $("#search").keyup(function(){
    clearTimeout(timer);
    var ms = 400; 
   var urlLocalization = "http://www.omdbapi.com/?s="+getSearch()+"&y=&plot=short&r=json&type=movie";
    timer = setTimeout(function() {
       $.ajax({
            type: "get",
            url: urlLocalization,
                async: false,

            success: function(data) {              
              var dataList = $("#listOfSearchs");
              dataList.empty();
              for(var i = 0; (i < 10) &&( i < data.totalResults);i++){
                   var opt ="<option value ='" + data.Search[i].Title +"' style=\"background-image:url(http://ia.media-imdb.com/images/M/MV5BMTQ0MzI1NjYwOF5BMl5BanBnXkFtZTgwODU3NDU2MTE@._V1._CR93,97,1209,1861_SX89_AL_.jpg_V1_SX300.jpg);\"></option>";
                    dataList.append(opt);
                }
            }
          });
    }, ms);


    $("#enviaDatos").click(function() {
         var urlMovie = "http://www.omdbapi.com/?s="+ getSearch()+"&y=&plot=short&r=json&type=movie";
                         var html = "";
          $.ajax({
            type: "get",
            url: urlMovie,

            success: function(data) {   
                  if(data.Response != "False"){
                        html +=  "<section class=\"movies\">\r\n";
                        var contador = 0;
                      for(var i = 0; (i < 4) && (i < data.totalResults);i++){ 
                         var urlId = "http://www.omdbapi.com/?i="+ data.Search[i].imdbID +"&plot=full&r=json";
                                  contador++;
                                  html+="<div class=\"movie\" title=\""+ data.Search[i].imdbID +"\">\r\n\
                                    <img src=\""; 
                                    if(data.Search[i].Poster == "N/A")
                                        html+="http://cdn4.areajugones.es/wp-content/uploads/2015/05/Batman-Arkham-Trofeo-Enigma.jpg";
                                    else
                                        html+=data.Search[i].Poster;
                                    html+="\" alt=\"\" class=\"poster\"\/>\r\n\
                                     <div class=\"title\">"+data.Search[i].Title+"<\/div>\r\n\
                                     <div class=\"info\">\r\n\
                                        <span class=\"length\">"+""+"<\/span>\r\n\
                                        <span class=\"year\">"+data.Search[i].Year+ "<\/span>\r\n\
                                       <\/div>\r\n\
                                       <div class=\"desc\" id=\""+ data.Search[i].imdbID +"\">\r\n\
                                        "+ "" +" <\/div>\r\n\
                                        <\/div>";
                              }
                          html +=  "<\/section>\r\n";

                          if(data.totalResults > 4){
                              html+=" <button type=\"button\" class=\"btn btn-info\">More movies</button></br></br>";
                            }
                        }

                        $("#listOfMovies").html(html);
                         if ($('#listOfMovies').is(':empty')){
                              $("#tituloPeliculas").hide();
                            }
                          else
                             $("#tituloPeliculas").show();

                      }
                    
              });

       var urlGame = "http://www.omdbapi.com/?s="+ getSearch() +"&y=&plot=short&r=json&type=game";
       var htmlGame = "";
       $.ajax({
            type: "get",
            url: urlGame,
            success: function(data) {   
                  if(data.Response != "False"){
                        htmlGame +=  "<section class=\"movies\">\r\n";
                        var contador = 0;
                      for(var i = 0; (i < 4) && (i < data.totalResults);i++){ 
                         var urlId = "http://www.omdbapi.com/?i="+ data.Search[i].imdbID +"&plot=full&r=json";
                                  contador++;
                                  htmlGame+="<div class=\"movie\" title=\""+ data.Search[i].imdbID +"\">\r\n\
                                    <img src=\""; 
                                    if(data.Search[i].Poster == "N/A")
                                        htmlGame+="http://vignette1.wikia.nocookie.net/donkeykong/images/4/43/Donkey_kong_pensativo.png/revision/latest?cb=20130606180457&path-prefix=es";
                                    else
                                        htmlGame+=data.Search[i].Poster;
                                    htmlGame+="\" alt=\"\" class=\"poster\"\/>\r\n\
                                     <div class=\"title\">"+data.Search[i].Title+"<\/div>\r\n\
                                     <div class=\"info\">\r\n\
                                        <span class=\"length\">"+""+"<\/span>\r\n\
                                        <span class=\"year\">"+data.Search[i].Year+ "<\/span>\r\n\
                                       <\/div>\r\n\
                                       <div class=\"desc\" id=\""+ data.Search[i].imdbID +"\">\r\n\
                                        "+ "dataById.Plot" +" <\/div>\r\n\
                                        <\/div>";
                              }

                          htmlGame +=  "<\/section>\r\n";

                          if(data.totalResults > 4){
                              htmlGame+=" <button type=\"button\" class=\"btn btn-info\">More games</button></br></br>";
                            }
                        }
                        $("#listOfGames").html(htmlGame);
                         if ($('#listOfGames').is(':empty')){
                              $("#tituloJuegos").hide();
                            }
                          else
                             $("#tituloJuegos").show();

                      }
                    
              });

       var urlSeries = "http://www.omdbapi.com/?s="+ getSearch() +"&y=&plot=short&r=json&type=series";
       var htmlSeries = "";
       $.ajax({
            type: "get",
            url: urlSeries,

            success: function(data) {   
                  if(data.Response != "False"){
                        htmlSeries +=  "<section class=\"movies\">\r\n";
                        var contador = 0;
                      for(var i = 0;(i < 4) && (i < data.totalResults);i++){ 
                         var urlId = "http://www.omdbapi.com/?i="+ data.Search[i].imdbID +"&plot=full&r=json";
                                  contador++;
                                  htmlSeries+="<div class=\"movie\" title=\""+ data.Search[i].imdbID +"\">\r\n\
                                    <img src=\""; 
                                    if(data.Search[i].Poster == "N/A")
                                        htmlSeries+="http://reactiongifs.me/wp-content/uploads/2014/10/tyrion-lannister-eyebrows-game-of-thrones.gif";
                                    else
                                        htmlSeries+=data.Search[i].Poster;
                                    htmlSeries+="\" alt=\"\" class=\"poster\"\/>\r\n\
                                     <div class=\"title\">"+data.Search[i].Title+"<\/div>\r\n\
                                     <div class=\"info\">\r\n\
                                        <span class=\"length\">"+""+"<\/span>\r\n\
                                        <span class=\"year\">"+data.Search[i].Year+ "<\/span>\r\n\
                                       <\/div>\r\n\
                                       <div class=\"desc\" id=\""+ data.Search[i].imdbID +"\">\r\n\
                                        "+ "dataById.Plot" +" <\/div>\r\n\
                                        <\/div>\r\n";
                              }

                          htmlSeries +=  "<\/section>\r\n";

                          if(data.totalResults > 4){
                              htmlSeries+=" <button type=\"button\" class=\"btn btn-info\" id=\"moreSeriesButton\">More series</button></br></br>";
                            }
                        }

                        $("#listOfSeries").html(htmlSeries);                        
                            checkIfNotSeries();
                            checkIfNotResults();

                      }

                   }); 


              }); 


        
            
    });
    $('#search').keypress(function (e) {
     var key = e.which;
     if(key == 13)  // the enter key code
      {
          $("#enviaDatos").click();       
          return false;  
      }
    });   
     $("#advanceSearch").click(function(){
            var url;
            var html="";
              if($('#radioMovies').is(":checked") || $('#radioGames').is(":checked") ||  $('#radioGames').is(":checked")){
                if($('#radioMovies').is(":checked")){
                   url = "http://www.omdbapi.com/?s="+ getSearch()+"&y=&plot=short&r=json&type=movie";

                 }
                else if($('#radioGames').is(":checked"))
                   url = "http://www.omdbapi.com/?s="+ getSearch()+"&y=&plot=short&r=json&type=game";            
                else if($('#radioGames').is(":checked"))
                   url = "http://www.omdbapi.com/?s="+ getSearch()+"&y=&plot=short&r=json&type=series";

               }
        });
  }); 

  function checkIfNotSeries(){
        if ($('#listOfSeries').is(':empty'))
           $("#tituloSeries").hide();
       else
            $("#tituloSeries").show();
  }
  function checkIfNotResults(){
      if ($('#listOfSeries').is(':empty') && $('#listOfGames').is(':empty') && $('#listOfMovies').is(':empty'))  
             $("#withoutResults").show();
      else
         $("#withoutResults").hide();
  }
A Pen created at CodePen.io. You can find this one at http://codepen.io/uroboroswww/pen/redLBp.

 Random quote generator for Free Code Camp zipline

Forked from [Charles Milam](http://codepen.io/CharlesMilam/)'s Pen [FCC - Random Quote Generator](http://codepen.io/CharlesMilam/pen/XbxyEW/).

Forked from [Charles Milam](http://codepen.io/CharlesMilam/)'s Pen [FCC - Random Quote Generator](http://codepen.io/CharlesMilam/pen/XbxyEW/).

Forked from [Charles Milam](http://codepen.io/CharlesMilam/)'s Pen [FCC - Random Quote Generator](http://codepen.io/CharlesMilam/pen/XbxyEW/).
* Functions in option `render` can now return a DOM node in addition to
  text. (#617)

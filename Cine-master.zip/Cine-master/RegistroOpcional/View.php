<?php
require './TransferUser.php';
$evento = isset($POST);
if(isset($_POST["altaUsuario"])){
	echo "nnnnnnnnnnnooooooo";
	echo $evento;
}

?>

		$(document).ready(function() {
			$('#fullpage').fullpage({
				verticalCentered: false,
				navigation:true,
				navigationTooltips: ['Inicio', '¿Qué es?', '¿A quien va dirigido?'],
				navigationPosition: 'left'
			});
		});
